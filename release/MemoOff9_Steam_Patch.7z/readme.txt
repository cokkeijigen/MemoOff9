使用方法，将补丁中的`MemoOff9_Steam.chs.exe`，`MemoOff9.dll`以及游戏自带的`steam_api64.dll` 放入 `data` 中，然后运行。

默认是简体中文，如需切换繁体中文或者日语，将exe重命名，将名字中的`.chs`替换成` .cht`或`.jps`即可。
